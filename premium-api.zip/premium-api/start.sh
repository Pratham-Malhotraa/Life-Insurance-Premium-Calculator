cd path/to/premium-api
git init
git add .
git commit -m "Initial Render deployment"
git remote add origin https://github.com/your-username/premium-api.git
git push -u origin master
#!/bin/bash
Rscript app.R
